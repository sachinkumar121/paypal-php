### Required Information

- Which language sample:
- Mode (Sandbox/Live):
- PayPal-Debug-ID(s) (from any logs):

### Issue Description
> Please include as many details (logs, steps to reproduce, screenshots) as you can to help us reproduce this issue faster.
